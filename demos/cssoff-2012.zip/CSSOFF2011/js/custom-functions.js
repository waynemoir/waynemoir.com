function addEvent(){
	// Add onclick function for changing featured image 
	$('#obstacle-selector li').each(function(i){
		$('#obstacle-selector li:eq('+i+') a').click(function(){
			return obstacleSelector(i);
			i+1;
		});
	});
}

function pullTitles(item, element){
	// Get data from img attributes and write to the page
	
	// Get data from page
	var ul = document.getElementById(item);
	var li = ul.getElementsByTagName('li'); 

	// Write span to page
	for (var i=0, len=li.length; i<len; i++) {
		var title = ul.getElementsByTagName('img')[i].getAttribute('title'); 
		ul.getElementsByTagName(element)[i].innerHTML+="<span>"+title+"</span>"; // Change featured text
	}
}

function obstacleSelector(id){
	// Change current item to match featured image
	
	// Variables
	var ul = document.getElementById('obstacle-selector');
	var li = ul.getElementsByTagName('li'); 
	var featured = document.getElementById('featured');

	// Clear current class
	for (var i=0, len=li.length; i<len; i++) {
		ul.getElementsByTagName('li')[i].setAttribute("class", ""); 
	}

	// Get data from page
	var title = ul.getElementsByTagName('img')[id].getAttribute('title'); 
	var alt = ul.getElementsByTagName('img')[id].getAttribute('alt'); 
	var href = ul.getElementsByTagName('a')[id].getAttribute('href'); 

	// Write to page
	featured.getElementsByTagName('h2')[0].innerHTML=title; // Change featured title
	featured.getElementsByTagName('p')[0].innerHTML=alt; // Change featured text
	featured.getElementsByTagName('img')[0].src=href; // Change featured image
	featured.getElementsByTagName('img')[0].setAttribute("alt", title); // Change featured alt
	ul.getElementsByTagName('li')[id].setAttribute("class", "current"); // Set current feature style

	return false;
}

function timerEnd(){
	// Change countdown message when time has run out
	$('#countdown h2').html('The clock has stopped :(');
}

function fadeInOut(element){
	// Opacity = 50% onload
	$(element).css("opacity","0.5");
 
	// On hover
	$(element).hover(function () { 
	// Opacity = 100%

	$(this).stop().animate({
		opacity: 1.0
		}, "slow");
	}, 

	// On mouse out
	function () { 
		// Opacity = 50%
		$(this).stop().animate({
			opacity: 0.5
		}, "slow");
	});
}

function showHideLink(){
	$(window).scroll(function () {
		if ($(this).scrollTop() > 100) {
			$('#back-top').css({visibility: "visible"});
		} else {
			$('#back-top').css({visibility: "hidden"});
		}
	});
}

function smoothScroll() {
	$('#site-nav a').bind('click',function(event){
		var $anchor = $(this);

		$('html, body').stop().animate({
			scrollTop: $($anchor.attr('href')).offset().top
		}, 1500,'easeInOutExpo');
		event.preventDefault();
	});
}