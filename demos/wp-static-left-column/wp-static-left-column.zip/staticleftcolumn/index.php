<?php get_header(); ?>
<section id="content" class="column">
	<h1 id="content-title">Primary Content</h1>
	<div id="content-wrapper">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<?php // Get posts ?> 
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<h1><a href="<?php the_permalink(); ?>" title="Permanent link to: <?php the_title(); ?>"><?php the_title(); ?></a></h1>
					<?php the_content(); ?>
					<?php wp_link_pages(); ?>
					<footer class="post-meta">
						<p>Published <time datetime="<?php the_time(get_option('date_format')); ?>" pubdate><?php the_time(get_option('date_format')); ?></time> under <?php the_category(','); ?>.</p>
						<?php the_tags('<ul><li class="first">Tags:</li><li>','</li><li>','</li></ul>'); ?>
						<?php edit_post_link('Edit Post', '<p>', '</p>'); ?>
					</footer><!-- .post-meta -->
				</article><!-- .post -->
			<?php // End posts ?> 
		<?php endwhile; else: ?>
			<p>Sorry, no posts matched your criteria.</p>
		<?php endif; ?>
		<nav id="pagination">
			<h1>Pagination</h1>
			<?php posts_nav_link(); ?>
		</nav>
	</div><!-- #content-wrapper -->
</section><!-- #content .column -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>