<aside id="sidebar" class="column">
<?php if ( !function_exists('dynamic_sidebar')
        || !dynamic_sidebar() ) : ?>
	<h1 id="sidebar-title">Sidebar</h1>
	<nav id="asides" >
		<h1>Asides</h1>
		<ul>
			<?php query_posts(array('category_name' => asides, 'showposts' => 6)); while (have_posts()) : the_post(); ?>
				<li><a href="<?php the_permalink(); ?>" title="Read the full post: <?php the_title(); ?>"><?php the_title(); ?></a></li>			
			<?php endwhile; ?>
			<li><a href="/notebook/category/asides/">Read more Asides&hellip;</a></li>
		</ul>					
	</nav><!-- #asides -->
	<section id="featured-photo">
		<h1>Featured Photo</h1>	
		<?php query_posts(array('orderby' => 'rand', 'category_name' => photography, 'showposts' => 1)); while (have_posts()) : the_post(); ?>
			<a href="<?php the_permalink(); ?>" title="Read the full post: <?php the_title(); ?>">
				<img src="<?php echo get_first_image() ?>" alt="<?php the_title(); ?>" />
			</a>					
		<?php endwhile; ?>
		<?php rewind_posts(); ?>	
	</section>					 
	<nav id="recent-posts">
		<h1>Recent Posts</h1>
		<ul>
			<?php query_posts(array('category__not_in' => asides, 'showposts' => 6)); while (have_posts()) : the_post(); ?>
				<li><a href="<?php the_permalink(); ?>" title="Read the full post: <?php the_title(); ?>"><?php the_title(); ?></a></li>			
			<?php endwhile; ?>
		</ul>					
	</nav><!-- #recent-posts -->
	
	<?php endif; ?>
</aside><!-- #sidebar .column -->	