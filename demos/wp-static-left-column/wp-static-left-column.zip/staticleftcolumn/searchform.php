<form action="/" method="get" id="site-search">
	<div class="first">
		<label for="search">Search for</label>
		<input type="text" id="search" name="s" onfocus="if(this.value==this.defaultValue)this.value=''" onblur="if(this.value=='')this.value=this.defaultValue" value="Search..." />
	</div>
	<div>
		<input type="submit" value="Go" id="go" />
	</div>
</form>