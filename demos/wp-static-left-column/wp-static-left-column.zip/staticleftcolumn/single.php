<?php get_header(); ?>
<section id="content" class="column">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php // Get posts ?>
			<div id="content-wrapper">
				<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<h1><?php the_title(); ?></h1>
					<?php the_content(); ?>
					<?php wp_link_pages(); ?>
					<footer class="post-meta">
						<p>Published <time datetime="<?php the_time(get_option('date_format')); ?>" pubdate><?php the_time(get_option('date_format')); ?></time> under <?php the_category(','); ?>.</p>
						<?php the_tags('<ul><li class="first">Tags:</li><li>','</li><li>','</li></ul>'); ?>
						<?php edit_post_link('Edit Post', '<p>', '</p>'); ?>
					</footer><!-- .post-meta -->
					<?php comments_template( '', true ); ?>
					<?php comment_form(); ?>
				</div>
			</div><!-- #content-wrapper -->
		<?php // End posts ?> 
	<?php endwhile; else: ?>
		<p>Sorry, no posts matched your criteria.</p>
	<?php endif; ?>	
</section><!-- #content .column -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>