<?php get_header(); ?>
<section id="content" class="column">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php // Get posts ?> 
			<div id="content-wrapper">
				<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<h1><?php the_title(); ?></h1>
					<?php the_content(); ?>
					<?php wp_link_pages(); ?>
					<?php edit_post_link('Edit Post', '<p>', '</p>'); ?>
				</div>
			</div><!-- #content-wrapper -->
		<?php // End posts ?> 
	<?php endwhile; else: ?>
		<p>Sorry, no posts matched your criteria.</p>
	<?php endif; ?>
</section><!-- #content .column -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>