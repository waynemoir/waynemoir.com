<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<title><?php
			/*
			 * Print the <title> tag based on what is being viewed.
			 */
			global $page, $paged;
			wp_title( '|', true, 'right' );
			// Add the blog name.
			bloginfo( 'name' );
			// Add the blog description for the home/front page.
			$site_description = get_bloginfo( 'description', 'display' );
			if ( $site_description && ( is_home() || is_front_page() ) )
				echo " | $site_description";
			// Add a page number if necessary:
			if ( $paged >= 2 || $page >= 2 )
				echo ' | ' . sprintf( __('Page %s'), max( $paged, $page ) );
			?>
		</title>
		<link rel="profile" href="http://gmpg.org/xfn/11" />		
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/screen.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/smallerscreen.css" media="only screen and (max-width: 1098px)" />
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/mobile.css" media="handheld, only screen and (max-width: 767px)" />
		<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/images/favicon.ico" type="image/x-icon" />
		<link type="application/rss+xml" rel="alternate" title="rss" href="<?php bloginfo('rss2_url'); ?>">
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
		<?php add_theme_support( 'automatic-feed-links' ); ?> 
		<?php wp_enqueue_script("jquery"); ?>
		<?php
			if ( is_singular() && get_option( 'thread_comments' ) )
				wp_enqueue_script( 'comment-reply' );
		?>
		<?php wp_head(); ?>
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/scripts/setup-site.js"></script>
	</head>
	<body <?php body_class(); ?> >
		<!--[if IE 6]><div id="ie6"><![endif]-->
		<!--[if IE 7]><div id="ie7"><![endif]-->
		<!--[if IE 8]><div id="ie8"><![endif]-->
			<div id="container">
				<header id="site-header">
					<?php // Get site name ?> 
						<h1>
							<a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>: Homepage" rel="home" id="logo">
								<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>
							</a>
						</h1>
						<p><?php echo esc_attr( get_bloginfo( 'description', 'display' ) ); ?></p>
					<?php // End site name ?>  
					<?php get_search_form(); ?>
					<?php query_posts('pagename=about'); ?>
					<?php while (have_posts()) : the_post(); ?>
						<?php the_content(); ?>
					<?php endwhile; ?>
					<?php wp_reset_query(); ?> 
					<?php if (current_user_can('level_10')){ ?> 
						<ul id="devbar" class="dev">
							<li class="title">Live Site</li>
							<?php wp_register(); ?>
							<li><?php wp_loginout(); ?></li>
						</ul>
					<?php }?>
				</header><!-- #site-header -->
				<nav id="site-nav">
					<h1>Site Navigation</h1>
					<?php wp_nav_menu( array( 'depth' => 1, 'container_class' => 'menu-header', 'theme_location' => 'primary' ) ); ?>
					<a href="#additional-nav" id="handheld-nav" title="View Site Navigation">View Site Navigation</a>
				</nav><!-- #site-nav -->