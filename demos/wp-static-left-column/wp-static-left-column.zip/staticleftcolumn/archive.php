<?php get_header(); ?>
<section id="content" class="column">		
	<div id="content-wrapper">
		<h1 id="section-title">
			<?php if ( is_day() ) : ?>
				<?php printf( __( 'Archive for %s'), get_the_date() ); ?>
			<?php elseif ( is_month() ) : ?>
				<?php printf( __( 'Archive for %s'), get_the_date('F Y') ); ?>
			<?php elseif ( is_year() ) : ?>
				<?php printf( __( 'Archive for %s'), get_the_date('Y') ); ?>
			<?php else : ?>
				Archive
			<?php endif; ?>	
		</h1>	
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<?php // Get posts ?> 
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<h1><a href="<?php the_permalink(); ?>" title="Permanent link to: <?php the_title(); ?>"><?php the_title(); ?></a></h1>
					<?php the_content(); ?>
					<?php wp_link_pages(); ?>
					<footer class="post-meta">
						<p>Published <time datetime="<?php the_time(get_option('date_format')); ?>" pubdate><?php the_time(get_option('date_format')); ?></time> in the <?php the_category(', '); ?> category.</p>
						<?php the_tags('<ul><li class="first">Tags:</li><li>','</li><li>','</li></ul>'); ?>
					</footer><!-- .post-meta -->
				</article><!-- .post -->
			<?php // End posts ?> 
		<?php endwhile; else: ?>
			<p>Sorry, no posts matched your criteria.</p>
		<?php endif; ?>
		<nav id="pagination">
			<h1>Pagination</h1>
			<?php posts_nav_link(); ?>
		</nav>
	</div><!-- #content-wrapper -->
</section><!-- #content .column -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>