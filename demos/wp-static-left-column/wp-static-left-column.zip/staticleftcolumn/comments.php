<section id="comments">
	<?php if ( have_comments() ) : ?>
		<h1>
			<?php
				printf( _n( 'One Response to %2$s', '%1$s Responses to %2$s', get_comments_number(), '' ),
				number_format_i18n( get_comments_number() ), '<em>' . get_the_title() . '</em>' );
			?>
		</h1>
		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
			<nav>
				<ul>
					<li><?php previous_comments_link(); ?></li>
					<li><?php next_comments_link(); ?></li>
				</ul>
			</nav>	
		<?php endif; ?>
		<ol>
			<?php wp_list_comments( ); ?>
		</ol>
		<?php if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) : ?>
			<nav>
				<ul>
					<li><?php previous_comments_link(); ?></li>
					<li><?php next_comments_link(); ?></li>
				</ul>
			</nav>
		<?php endif; ?>
	<?php else : ?>
		<?php if ( ! comments_open() ) : ?>
			<h1>Comments are closed.</h1>
		<?php endif; ?>
	<?php endif; ?>
</section><!-- #comments -->
