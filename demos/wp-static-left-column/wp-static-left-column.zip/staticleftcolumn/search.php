<?php get_header(); ?>
<section id="content" class="column">
	<div id="content-wrapper">
		<div class="post">
			<?php
			global $query_string;
			$query_args = explode("&", $query_string);
			$search_query = array();
			foreach($query_args as $key => $string) {
				$query_split = explode("=", $string);
				$search_query[$query_split[0]] = $query_split[1];
			} // foreach
			$search = new WP_Query($search_query);
			?>
			<h1>
				<?php
				global $wp_query;
				$total_results = $wp_query->found_posts;
				echo $total_results;
				?> Search Results Found for <?php the_search_query(); ?>
			</h1>
			<ul>
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<li>
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						<br/>
						Posted under <?php the_category(' '); ?> on <?php the_time('d/m/Y') ?>
					</li>
				<?php endwhile; else: ?>
					<p>Sorry, no posts matched your criteria.</p>
				<?php endif; ?>
			</ul>
		</div><!-- .post -->
	</div><!-- #content-wrapper -->
</section><!-- #content .column -->
<?php get_sidebar(); ?>	
<?php get_footer(); ?>