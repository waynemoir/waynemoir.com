//ie html5
	document.createElement('header');
	document.createElement('hgroup');
	document.createElement('nav');
	document.createElement('menu');
	document.createElement('section');
	document.createElement('article');
	document.createElement('aside');
	document.createElement('footer');
	document.createElement('time'); 
//equal heights
	function setEqualHeight(columns) {
		var tallestcolumn = 0;
		columns.each(
			function() {
				currentHeight = jQuery(this).height();
				if(currentHeight > tallestcolumn) {
					tallestcolumn  = currentHeight;
				}
			}
		);
		columns.height(tallestcolumn);
	}
	jQuery(document).ready(function($) {
		setEqualHeight($("#container .column"));
	});