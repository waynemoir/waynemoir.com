<?php get_header(); ?>
<section id="content" class="column">		
	<h1 id="content-title">Primary Content</h1>					
	<div id="content-wrapper">
		<article class="post">
			<h1>Oops!</h1>
			<p>The page you were looking for appears to have been moved, deleted or does not exist. Perhaps you could try using the <a id="sitemap" href="/site-map/">sitemap</a> or returning to the <a href="<?php echo home_url( '/' ); ?>">home page</a>.</p>
		</article><!-- .post -->
	</div><!-- #content-wrapper -->	
</section><!-- #content .column -->			
<?php get_sidebar(); ?>	
<?php get_footer(); ?>