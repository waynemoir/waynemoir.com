				<footer id="site-footer">
					<nav id="categories">
						<h1>Categories</h1>
						<ul>
							<?php wp_list_categories('show_count=1&title_li=&hierarchical=0'); ?>
						</ul>
					</nav>	<!-- #categories -->				
					<nav id="additional-nav">
						<h1>Additional Navigation</h1>
						<ul>
							<li><a href="#container" id="top" title="Return to the top">Top</a></li>
						</ul>
						<?php wp_nav_menu( array( 'depth' => 1) ); ?>
					</nav>
					<p id="copyright"><?php $copyYear = 2005; $curYear = date('Y');echo $copyYear . (($copyYear != $curYear) ? '-' . $curYear : ''); ?> <a href="http://www.waynemoir.com/" title="Wayne Moir">Wayne Moir</a>. All rights reserved.</p>
				</footer><!-- #site-footer -->
			</div><!-- #container -->
		<!--[if lte IE 8]></div><![endif]-->
		<?php wp_footer(); ?>
	</body>
</html>