// IE HTML5 support
document.createElement('header');
document.createElement('hgroup');
document.createElement('nav');
document.createElement('menu');
document.createElement('section');
document.createElement('article');
document.createElement('aside');
document.createElement('footer');
document.createElement('time');  

	 
//  Toggle Display of Exercises
function toggle(ElementID) {
	var element = document.getElementById(ElementID);
	if (element.style.display != 'none' ) {
		element.style.display = 'none';
	}
	else {
		element.style.display = 'block';
	}
}
// Hide Exercise Solutions by Default
function changeStyle()
{
	var div = document.getElementsByClassName("solution");
	Array.prototype.forEach.call(div, function (item) { item.style.display = "none";});
}
window.onload = changeStyle;