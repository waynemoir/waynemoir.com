//Equal heights columns
function setEqualHeight()
{
	jQuery('.column').height('');
	var highestCol = Math.max(jQuery('#sidebar').height(),jQuery('#content').height());
	jQuery('.column').height(highestCol);
}
//Execute on page load
jQuery(window).load(function() {
	setEqualHeight();
});
//Execute on resize
jQuery(window).resize(function() {
	setEqualHeight();
});