<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>" />
		<title>
			<?php
			/*
			 * Print the <title> tag based on what is being viewed.
			 */
			global $page, $paged;
			wp_title( '|', true, 'right' );
			// Add the blog name.
			bloginfo( 'name' );
			// Add the blog description for the home/front page.
			$site_description = get_bloginfo( 'description', 'display' );
			if ( $site_description && ( is_home() || is_front_page() ) )
				echo " | $site_description";
			// Add a page number if necessary:
			if ( $paged >= 2 || $page >= 2 )
				echo ' | ' . sprintf( __( 'Page %s' ), max( $paged, $page ) );
			?>
		</title>
		<meta name="description" content="The online notebook and blog of Wayne Moir, Professional Web Designer" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
		<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/screen.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/smallerscreen.css" media="only screen and (max-width: 970px)" />
		<link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/mobile.css" media="handheld, only screen and (max-width: 767px)" />
		<link type="application/rss+xml" rel="alternate" title="rss" href="<?php bloginfo('rss2_url'); ?>">
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
		<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico" type="image/x-icon" />
		<script type="text/javascript" src="<?php echo get_settings('home'); ?>/wp-includes/js/jquery/jquery.js"></script>
		<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/scripts/preload.js"></script>
		<?php if( is_page('contact') ){ ?>
			<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/scripts/jquery.validate.min.js"></script>
			<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/scripts/verify.js"></script>
		<?php }?>
		<?php wp_head(); ?>
	</head>
	<body <?php body_class(); ?> id="the-top">
		<!--[if IE 6]><div id="ie6"><![endif]-->
		<!--[if IE 7]><div id="ie7"><![endif]-->
		<!--[if IE 8]><div id="ie8"><![endif]-->
			<header id="site-header">
				<div class="container">
					<?php // Get site name ?> 
						<h1>
							<a href="<?php echo home_url( '/' ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>: Homepage" rel="home" id="logo">
								<img src="<?php bloginfo('template_directory'); ?>/images/logo.png" alt="Wayne Moir" />
							</a>
						</h1>
					<?php // End site name ?>  
					<nav id="site-nav">
						<h1>Site Navigation</h1>
						<ul>
							<li><a href="/">Home</a></li>
							<li><a href="/archive/">Archive</a></li>
							<li><a href="/about/">About</a></li>
							<li><a href="/contact/">Contact</a></li>
						</ul>
					</nav><!-- #site-nav -->
				</div><!-- .container -->
			</header><!-- #site-header -->
			<a href="#additional-nav" id="handheld-nav" title="View Site Navigation">View Site Navigation</a>
			<div class="container">