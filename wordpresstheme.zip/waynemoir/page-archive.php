<?php 
/* Template Name: Archive */
get_header(); ?>
<section id="content" class="column">
<?php query_posts($query_string . '&cat=-33'); ?>
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php // Get posts ?>
			<div id="content-wrapper">
				<div class="post">
					<h1><?php the_title(); ?></h1>
					<?php the_content(); ?>
					<ul>
						
						<?php wp_get_archives('type=monthly'); ?>
					</ul>
					<h1>Archive by Category</h1>
					<ul>
						<?php wp_list_categories('show_count=1&title_li=&exclude=33'); ?>
					</ul>
					<?php edit_post_link('Edit Post', '<p>', '</p>'); ?>
				</div>
			</div><!-- #content-wrapper -->
		<?php // End posts ?> 
	<?php endwhile; else: ?>
		<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
	<?php endif; ?>
</section><!-- #content .column -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>