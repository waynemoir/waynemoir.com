<?php get_header(); ?>
<section id="content" class="column">
	<div id="content-wrapper">
		<h1 id="section-title">
			<?php if ( is_day() ) : ?>
				<?php printf( __( 'Archive for %s'), get_the_date() ); ?>
			<?php elseif ( is_month() ) : ?>
				<?php printf( __( 'Archive for %s'), get_the_date('F Y') ); ?>
			<?php elseif ( is_year() ) : ?>
				<?php printf( __( 'Archive for %s'), get_the_date('Y') ); ?>
			<?php elseif ( is_category() ) : ?>
				<?php echo single_cat_title(); ?> 
			<?php elseif ( is_tag() ) : ?>
				<?php echo single_tag_title(); ?> 
			<?php else : ?>
				<?php _e( 'Archive'); ?>
			<?php endif; ?>	
		</h1>

		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<article class="post">
					<h1><?php the_title(); ?></h1>
					<?php the_content(); ?>
					<footer class="post-meta">
						<p>Published <time datetime="<?php the_time('Y-m-d'); ?>" pubdate><?php the_time('F jS Y'); ?></time> in the <?php the_category(', '); ?> category.</p>
						<?php the_tags('<ul><li class="first">Tags:</li><li>','</li><li>','</li></ul>'); ?>
						<p>Permalink: <a href="<?php the_permalink(); ?>" title="Permanent link to: <?php the_title(); ?>"><?php the_title(); ?></a></p>
						<?php edit_post_link('Edit Post', '<p>', '</p>'); ?>
					</footer><!-- .post-meta -->
				</article><!-- .post -->
		<?php endwhile; else: ?>
			<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
		<?php endif; ?>

		<nav id="pagination">
			<h1>Pagination</h1>
			<?php if (function_exists("pagination")) {
				pagination($additional_loop->max_num_pages);
			} ?>
		</nav>
	</div><!-- #content-wrapper -->
</section><!-- #content .column -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>