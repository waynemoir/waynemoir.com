<?php get_header(); ?>
<section id="content" class="column">
	<div id="content-wrapper">
		<h1 id="section-title">
			<?php if ( is_day() ) : ?>
				<?php printf( __( 'Archive for %s'), get_the_date() ); ?>
			<?php elseif ( is_month() ) : ?>
				<?php printf( __( 'Archive for %s'), get_the_date('F Y') ); ?>
			<?php elseif ( is_year() ) : ?>
				<?php printf( __( 'Archive for %s'), get_the_date('Y') ); ?>
			<?php elseif ( is_category() ) : ?>
				<?php echo single_cat_title(); ?> 
			<?php elseif ( is_tag() ) : ?>
				<?php echo single_tag_title(); ?> 
			<?php else : ?>
				<?php _e( 'Archive'); ?>
			<?php endif; ?>	
		</h1>
		<?php if ( in_category('Inspiration') ) {
			query_posts('cat=33&posts_per_page=10');
		?>
			<nav id='category-taglist'>
				<?php
				$args = array(
					'categories' => '33'
				);
				$tags = get_category_tags($args);
				$content .= "<ul>";
				foreach ($tags as $tag) {
					$content .= "<li><a href=\"$tag->tag_link\">$tag->tag_name</a></li>";
				}
				$content .= "</ul>";
				echo single_cat_title().' Tags';
				echo $content;
				?>
			</nav>

			<ul id="inspiration-list">
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
						<li>
								<a href="<?php the_permalink(); ?>" 
									<?php
									$posttags = get_the_tags();
									if ($posttags) 
									{
										echo 'title="Tags: '; 
										foreach($posttags as $tag)
										{
											echo $tag->name . ' '; 
										}
										echo '"'; 
									}
									echo ' >'; 
									?>
									<?php get_attached_images('full'); ?>
								</a>
							</li>
						
					<?php endwhile; else: ?>
						<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
					<?php endif; ?>
			</ul>
					<? } ?>
		<nav id="pagination">
			<h1>Pagination</h1>
			<?php if (function_exists("pagination")) {
				pagination($additional_loop->max_num_pages);
			} ?>
		</nav>
	</div><!-- #content-wrapper -->
</section><!-- #content .column -->
<?php get_footer(); ?>