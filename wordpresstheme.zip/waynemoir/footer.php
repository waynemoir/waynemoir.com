			</div><!-- .container -->
			<footer id="site-footer">
				<nav id="categories">
					<div class="container">
						<h1>Notebook Categories</h1>
						<ul>
							<?php wp_list_categories('show_count=1&title_li=&exclude=33'); ?>
						</ul>
					</div><!-- .container -->
				</nav><!-- #categories -->
				<div class="container">
					<nav id="additional-nav">
						<h1>Additional Navigation</h1>
						<ul>
							<li class="handheld"><a href="/" class="btn">Home</a></li>
							<li class="handheld"><a href="/archive/" class="btn">Archive</a></li>
							<li class="handheld"><a href="/about/" class="btn">About</a></li>
							<li class="handheld"><a href="/contact/" class="btn">Contact</a></li>
							<li><a id="sitemap" href="/site-map/">Site map</a></li>
							<li><a href="#the-top" id="top" title="Return to the top">Top</a></li>
						</ul>
					</nav><!-- #additional-nav -->
					<p id="copyright"><?php $copyYear = 2005; $curYear = date('Y');echo $copyYear . (($copyYear != $curYear) ? '-' . $curYear : ''); ?> <a href="/wp-admin/" title="Wayne Moir">Wayne Moir</a>. All rights reserved.</p>
				</div><!-- .container -->
			</footer><!-- #site-footer -->
		<!--[if lte IE 8]></div><![endif]-->
		<script type="text/javascript">
			var _gaq = _gaq || [];
			_gaq.push(['_setAccount', 'UA-9805583-1']);
			_gaq.push(['_trackPageview']);
			(function() {
				var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
				ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
			})();
		</script>
		<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/scripts/equalheight.js"></script>
		<?php wp_footer(); ?>
	</body>
</html>