<?php get_header(); ?>
<section id="content" class="column">
	<h1 id="content-title">Primary Content</h1>
	<div id="content-wrapper">
	<?php 
	// Hide posts in the inspriation category
	query_posts( array( 'cat' => -33, 'paged' => get_query_var('paged') ) );
	?> 
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<?php // Get posts ?> 
				<article class="post">
					<h1><?php the_title(); ?></h1>
					<?php the_content(); ?>
					<footer class="post-meta">
						<p>Published <time datetime="<?php the_time('Y-m-d'); ?>" pubdate><?php the_time('F jS Y'); ?></time> in the <?php the_category(', '); ?> category.</p>
						<?php the_tags('<ul><li class="first">Tags:</li><li>','</li><li>','</li></ul>'); ?>
						<p>Permalink: <a href="<?php the_permalink(); ?>" title="Permanent link to: <?php the_title(); ?>"><?php the_title(); ?></a></p>
						<?php edit_post_link('Edit Post', '<p>', '</p>'); ?>
					</footer><!-- .post-meta -->
				</article><!-- .post -->
			<?php // End posts ?> 
		<?php endwhile; else: ?>
			<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
		<?php endif; ?>
		<nav id="pagination">
			<h1>Pagination</h1>
			<?php if (function_exists("pagination")) {
				pagination($additional_loop->max_num_pages);
			} ?>
		</nav>
	</div><!-- #content-wrapper -->
</section><!-- #content .column -->
<?php get_sidebar(); ?>	
<?php get_footer(); ?>