<?php get_header(); ?>
<section id="content" class="column">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php // Get posts ?> 
			<div id="content-wrapper">
				<div class="post">
					<h1><?php the_title(); ?></h1>
					<?php the_content(); ?>
					<?php edit_post_link('Edit Post', '<p>', '</p>'); ?>
				</div>
			</div><!-- #content-wrapper -->
		<?php // End posts ?> 
	<?php endwhile; else: ?>
		<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
	<?php endif; ?>
</section><!-- #content .column -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>