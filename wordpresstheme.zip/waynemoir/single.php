<?php get_header(); ?>
<section id="content" class="column">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php // Get posts ?> 
			<div id="content-wrapper">
				<div class="post">
					<h1><?php the_title(); ?></h1>
					<?php the_content(); ?>
					<footer class="post-meta">
						<p>Published <time datetime="<?php the_time('Y-m-d'); ?>" pubdate><?php the_time('F jS Y'); ?></time> in the <?php the_category(', '); ?> category.</p>
						<?php the_tags('<ul><li class="first">Tags:</li><li>','</li><li>','</li></ul>'); ?>
						<?php edit_post_link('Edit Post', '<p>', '</p>'); ?>
					</footer><!-- .post-meta -->
				</div>
			</div><!-- #content-wrapper -->
		<?php // End posts ?> 
	<?php endwhile; else: ?>
		<p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
	<?php endif; ?>
</section><!-- #content .column -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>