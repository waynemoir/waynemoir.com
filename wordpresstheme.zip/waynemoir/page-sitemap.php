<?php 
/* Template Name: Sitemap */
get_header(); ?>
<section id="content" class="column">
	<div id="content-wrapper">
		<div class="post">
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<h1><?php the_title(); ?></h1>
				<?php the_content(); ?>
			<?php endwhile; endif; ?>
			<!-- Category Archive Start -->
			<ul id="sitemap">
				<li><a href="/">Home</a></li>
				<li><a href="/about/">About</a></li>
				<li><a href="/contact/">Contact</a></li>
				<li><a href="/archive/">Archive</a>
					<ul>
					<?php
						$catQuery = $wpdb->get_results("SELECT * FROM $wpdb->terms AS wterms INNER JOIN $wpdb->term_taxonomy AS wtaxonomy ON ( wterms.term_id = wtaxonomy.term_id ) WHERE wtaxonomy.taxonomy = 'category' AND wtaxonomy.parent = 0 AND wtaxonomy.count > 0");

						$catCounter = 0;
						foreach ($catQuery as $category) 
						{
							$catCounter++;
							$catStyle = '';
							if (is_int($catCounter / 2)) $catStyle = ' class="catAlt"';
							$catLink = get_category_link($category->term_id);
							echo '<li'.$catStyle.'><a href="'.$catLink.'" title="'.$category->name.'">'.$category->name.'</a>';
								echo '<ul>';
									query_posts('cat='.$category->term_id.'');?>
									<?php while (have_posts()) : the_post(); ?>
										<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></li>
									<?php endwhile; ?>
								</ul>
							</li>
						<?php }	?>
					</ul>
				</li>
			</ul><!-- Category Archive End -->
		</div><!-- #content-wrapper -->
	</div>
</section><!-- #content .column -->
<?php get_sidebar(); ?>	
<?php get_footer(); ?>