<aside id="sidebar" class="column">
	<h1 id="sidebar-title">Sidebar</h1>
	<nav id="asides" >
		<h1>Asides</h1>
		<ul>
			<?php query_posts(array('category_name' => asides, 'showposts' => 6)); while (have_posts()) : the_post(); ?>
				<li><a href="<?php the_permalink(); ?>" title="Read the full post: <?php the_title(); ?>"><?php the_title(); ?></a></li>
			<?php endwhile; ?>
			<li><a href="/notebook/category/asides/">Read more Asides&hellip;</a></li>
		</ul>
	</nav><!-- #asides -->
	<section id="search">
		<?php get_search_form(); ?>
	</section><!-- #search -->
	<section id="featured-photo">
		<h1>Featured Photo</h1>
		<?php query_posts(array('orderby' => 'rand', 'category_name' => photography, 'showposts' => 1)); while (have_posts()) : the_post(); ?>
			<a href="<?php the_permalink(); ?>" title="Read the full post: <?php the_title(); ?>">
				<img src="<?php echo get_first_image() ?>" alt="<?php the_title(); ?>" />
			</a>
		<?php endwhile; ?>
		<?php rewind_posts(); ?>
	</section><!-- #featured-photo -->
	<nav id="recent-posts">
		<h1>Recent Posts</h1>
		<ul>
			<?php query_posts(array('cat' => '-33,-13', 'showposts' => 6)); while (have_posts()) : the_post(); ?>
				<li><a href="<?php the_permalink(); ?>" title="Read the full post: <?php the_title(); ?>"><?php the_title(); ?></a></li>
			<?php endwhile; ?>
		</ul>
	</nav><!-- #recent-posts -->
	<section>
		<h1>About This Site</h1>
		<?php query_posts('pagename=about the site'); ?>
			<?php while (have_posts()) : the_post(); ?>
				<?php the_content(); ?>
			<?php endwhile; ?>
		<?php wp_reset_query(); ?>
	</section>
	<?php if (current_user_can('level_10')){ ?> 
		<section id="devbar" class="live">
			<h1>Live Site</h1>
			<ul>
				<li><a href="<?php pageURL(); ?>?theme=Wayne+Moir+Dev&passkey=9678004304d50022f0087b">Switch to Dev</a></li>
				<li><a href="<?php pageURL(); ?>?theme=Wayne+Moir+Free&passkey=9678004304d50022f0087b">Switch to Free</a></li>
				<li><a href="<?php pageURL(); ?>?theme=Wayne+Moir+Old+One&passkey=9678004304d50022f0087b">Switch to Old One</a></li>
				<?php wp_register(); ?>
				<li><?php wp_loginout(); ?></li>
			</ul>
		</section>
	<?php }?>
</aside><!-- #sidebar .column -->