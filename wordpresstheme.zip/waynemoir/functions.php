<?php
/* Returns a "Continue Reading" link for excerpts */
function continue_reading_link() {
	return ' <a href="'. get_permalink() . '">' . __( 'Read More' ) . '</a>';
}
function auto_excerpt_more( $more ) {
	return ' &hellip;' . continue_reading_link();
}
add_filter( 'excerpt_more', 'auto_excerpt_more' );
/* pagination*/
function pagination($pages = '', $range = 4)
{
	$showitems = ($range * 2)+1; 

	global $paged;
	if(empty($paged)) $paged = 1;

	if($pages == '')
	{
		global $wp_query;
		$pages = $wp_query->max_num_pages;
		if(!$pages)
		{
			$pages = 1;
		}
	}  
 
	if(1 != $pages)
	{
		echo "<ul><li class=\"index\">Page ".$paged." of ".$pages."</li>";
		if($paged > 2 && $paged > $range+1 && $showitems < $pages) echo "<li><a href='".get_pagenum_link(1)."'>&laquo; First</a></li>";
		if($paged > 1 && $showitems < $pages) echo "<li><a href='".get_pagenum_link($paged - 1)."'>&lsaquo; Previous</a></li>";

		for ($i=1; $i <= $pages; $i++)
		{
			if (1 != $pages &&( !($i >= $paged+$range+1 || $i <= $paged-$range-1) || $pages <= $showitems ))
			{
				echo ($paged == $i)? "<li class=\"current\">".$i."</li>":"<li><a href='".get_pagenum_link($i)."' >".$i."</a></li>";
			}
		}
 
		if ($paged < $pages && $showitems < $pages) echo "<li><a href=\"".get_pagenum_link($paged + 1)."\">Next &rsaquo;</a></li>";
		if ($paged < $pages-1 &&  $paged+$range-1 < $pages && $showitems < $pages) echo "<li><a href='".get_pagenum_link($pages)."'>Last &raquo;</a></li>";
		echo "</ul>\n";
     }
}

/* double line title*/
function title_length(){
	$string = get_the_title(); 
	$num_char=strlen($string);
	if	($num_char >= 40){	
		echo "double";
	}
}

/*first image */
function get_first_image() 
{
	$files = get_children('post_parent='.get_the_ID().'&post_type=attachment&post_mime_type=image');
	if($files) :
	$keys = array_reverse(array_keys($files));
	$j=0;
	$num = $keys[$j];
	$image=wp_get_attachment_image($num, 'large', false);
	$imagepieces = explode('"', $image);
	$imagepath = $imagepieces[1];
	$thumb=wp_get_attachment_thumb_url($num);
	echo $thumb;
	endif;
}

function content($limit) 
{
	$link = get_permalink();
	$title = get_the_title(); 
	$content = explode(' ', get_the_content(), $limit);
	if (count($content)>=$limit) 
	{
		array_pop($content);
		$content = implode(" ",$content).'&hellip;<a href="'.$link.'" title="'.$title.'" class="read-more">'.__("Read More").'</a>';
		} 
		else 
		{
		$content = implode(" ",$content);
	}
	$content = preg_replace('/\[.+\]/','', $content);
	$content = apply_filters('the_content', $content); 
	$content = str_replace(']]>', ']]&gt;', $content);
	return $content;
}

/* more link */
add_filter( 'the_content_more_link', 'custom_more_link', 10, 2 );
function custom_more_link( $more_link, $more_link_text ) 
{
	return str_replace( $more_link_text, 'Read More', $more_link );
}

/*wp_nav_menu support in one location.*/
	register_nav_menus( array(
		'primary' => __( 'Primary Navigation', 'twentyten' ),
	) );
	function pageURL() {/* theme switching */
	$pageURL = 'http';
	if ($_SERVER["HTTPS"] == "on") {
		$pageURL .= "s";
	}
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") {
		$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	}
	else 
	{
		$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	}
}

/*Remove rel="EditURI" - Windows Live Writer */
remove_action( 'wp_head', 'wlwmanifest_link' ); // Display the link to the Windows Live Writer manifest file.


  function get_attached_images($attachment_size){
	//valid parameters: "thumbnail", "medium", "large" and "full" 
  
    // This function runs in "the_loop", you could run this out of the loop but
    // you would need to change this to $post = $valid_post or something other than
    // using the global post declaration.
    global $post; 
    $args = array(
      'post_type' => 'attachment',
      'numberposts' => 1,
      'post_status' => null,
      'post_parent' => $post->ID,
      'order' => 'ASC',
      'orderby' => 'menu_order'
      ); 
    $attachment = get_posts($args); // Get attachment
    if ($attachment) {
      $img = wp_get_attachment_image_src($attachment[0]->ID, $size = $attachment_size); 
   //   echo "<img src='".$img[0]."' alt='".the_title()."' />";
	echo "<img alt='";
	echo the_title();
	echo "' src='". $img[0]."' /><br>";
  }
  }
  function get_category_tags($args) {
	global $wpdb;
	$tags = $wpdb->get_results
	("
		SELECT DISTINCT terms2.term_id as tag_id, terms2.name as tag_name, null as tag_link
		FROM
			wp_posts as p1
			LEFT JOIN wp_term_relationships as r1 ON p1.ID = r1.object_ID
			LEFT JOIN wp_term_taxonomy as t1 ON r1.term_taxonomy_id = t1.term_taxonomy_id
			LEFT JOIN wp_terms as terms1 ON t1.term_id = terms1.term_id,

			wp_posts as p2
			LEFT JOIN wp_term_relationships as r2 ON p2.ID = r2.object_ID
			LEFT JOIN wp_term_taxonomy as t2 ON r2.term_taxonomy_id = t2.term_taxonomy_id
			LEFT JOIN wp_terms as terms2 ON t2.term_id = terms2.term_id
		WHERE
			t1.taxonomy = 'category' AND p1.post_status = 'publish' AND terms1.term_id IN (".$args['categories'].") AND
			t2.taxonomy = 'post_tag' AND p2.post_status = 'publish'
			AND p1.ID = p2.ID
		ORDER by tag_name
	");
	$count = 0;
	foreach ($tags as $tag) {
		$tags[$count]->tag_link = get_tag_link($tag->tag_id);
		$count++;
	}
	return $tags;
}

add_filter( 'getarchives_where', 'customarchives_where' );

function customarchives_where( $x ) {

	global $wpdb;

	$s = $x;

	$s =  $s . " AND $wpdb->posts.ID IN ";

	$s = $s . "(";
	$s = $s . "SELECT $wpdb->posts.ID FROM $wpdb->posts INNER JOIN $wpdb->term_relationships ON ($wpdb->posts.ID = $wpdb->term_relationships.object_id) INNER JOIN $wpdb->term_taxonomy ON ($wpdb->term_relationships.term_taxonomy_id = $wpdb->term_taxonomy.term_taxonomy_id) WHERE $wpdb->term_taxonomy.taxonomy = 'category'";

	$exclude = '33'; // category id or list of id's to exclude

	$s = $s . " AND $wpdb->term_taxonomy.term_id NOT IN ($exclude)";
	$s = $s . ")";

	return $s;

}